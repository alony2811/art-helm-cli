## art-helm-cli

## Requirements:
1. minikube with minimun 4GB Memory and 4 CPUS - https://minikube.sigs.k8s.io/docs/start/
2. kubectl (configure to your minikube cluster) - https://kubernetes.io/docs/tasks/tools/install-kubectl/
